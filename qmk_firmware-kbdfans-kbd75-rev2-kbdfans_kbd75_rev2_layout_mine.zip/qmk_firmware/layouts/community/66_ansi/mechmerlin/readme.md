# MechMerlin's 66_ansi layout

This is the 66 key layout used by u/merlin36, host of the [MechMerlin](www.youtube.com/mechmerlin) 
YouTube channel.

It is used on his   
* [Clueboard 66 rev4](https://github.com/qmk/qmk_firmware/tree/master/keyboards/clueboard/66/rev4)
* [Clueboard 66 hotswap gen1](https://github.com/qmk/qmk_firmware/tree/master/keyboards/clueboard/66_hotswap/gen1)
* [Clueboard 66 hotswap prototype](https://github.com/qmk/qmk_firmware/tree/master/keyboards/clueboard/66_hotswap/prototype)
* [Clueboard 66 rev1](https://github.com/qmk/qmk_firmware/tree/master/keyboards/clueboard/66/rev1)

### Build
To build the firmware file associated with this keymap, simply run `make your_keyboard:mechmerlin`.